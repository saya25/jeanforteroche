insert into t_article values
(1, 'Premier article', 'Description du premier article');
insert into t_article values
(2, 'Deuxième article', 'Description du deuxième article');
insert into t_article values
(3, 'Troisième article', "Description du troisième article");

insert into t_user values
(1, 'admin', '$2y$13$A8MQM2ZNOi99EW.ML7srhOJsCaybSbexAj/0yXrJs4gQ/2BqMMW2K', 'EDDsl&fBCJB|a5XUtAlnQN8', 'ROLE_ADMIN');


insert into t_comment values
(1, 'Premier commentaire', 'Clément', 1);
insert into t_comment values
(2, 'Deuxième commentaire', 'Paul', 1);


insert into t_reply values
(1, 'Premier sous-commentaire', 'Jacques', 1, 0, 1);
insert into t_reply values
(2, 'Deuxième sous-commentaire', 'Louis', 2, 0, 1);