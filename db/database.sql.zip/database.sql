create database if not exists jeanforteroche character set utf8 collate utf8_unicode_ci;
use jeanforteroche;

grant all privileges on jeanforteroche.* to 'jeanforteroche'@'localhost' identified by 'secret';